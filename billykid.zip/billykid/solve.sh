#!/bin/bash

pre.py | clingo encoding.asp /dev/stdin --out-ifs=\\n --quiet=1 | egrep 'select' | post.py

