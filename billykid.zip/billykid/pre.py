#!/usr/bin/env python3

"""
Example input:

6 7 3
1 4
1 2
2 3
3 4
3 5
4 5
5 6
"""

towns, connections, towns_in_travel = [int(x) for x in input().split()]

connection = []
for _ in range(connections):
    connection.append([int(x) for x in input().split()])

print(f"town(1..{towns}).")
print(f"townsintravel({towns_in_travel}).")

for c in connection:
    print(f"connected({c[0]},{c[1]}).")

