#!/usr/bin/env python3

import fileinput
import re

pattern = re.compile('^select\((?P<town>\d+)\)$')

res = []

for line in fileinput.input():
    m = pattern.match(line)
    assert m
    res.append(m.group('town'))

assert res

print(len(res))
print(' '.join(sorted(res)))
